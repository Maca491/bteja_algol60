public class SemanticAnalyzer : AlgolSubsetBaseVisitor<object>
{
    // Hierarchick� tabulka symbol� pro podporu vno�en�ch rozsah�
    private Stack<Dictionary<string, SymbolInfo>> scopes = new Stack<Dictionary<string, SymbolInfo>>();
    private Dictionary<string, SymbolInfo> currentScope => scopes.Peek();

    public class SymbolInfo
    {
        public string Type { get; set; }
        public SymbolKind Kind { get; set; }
        public string ReturnType { get; set; } // Pro funkce
        public bool IsArray { get; set; }
        public bool IsFunctionType { get; set; } // NOV�: Je to funk�n� typ?
    }

    public enum SymbolKind
    {
        Variable,
        Procedure,
        Function
    }

    public SemanticAnalyzer()
    {
        // Glob�ln� rozsah
        scopes.Push(new Dictionary<string, SymbolInfo>());
    }

    private void EnterScope()
    {
        scopes.Push(new Dictionary<string, SymbolInfo>());
    }

    private void ExitScope()
    {
        scopes.Pop();
    }

    private SymbolInfo LookupSymbol(string name)
    {
        // Hled� symbol od aktu�ln�ho rozsahu sm�rem ke glob�ln�mu
        foreach (var scope in scopes)
        {
            if (scope.ContainsKey(name))
            {
                return scope[name];
            }
        }
        return null;
    }

    private bool DeclareSymbol(string name, SymbolInfo info)
    {
        if (currentScope.ContainsKey(name))
        {
            Console.WriteLine($"Chyba: Symbol '{name}' je ji� deklarov�n v aktu�ln�m rozsahu.");
            return false;
        }
        currentScope[name] = info;
        return true;
    }

    public override object VisitVariable_decl(AlgolSubsetParser.Variable_declContext context)
    {
        var varNames = context.ident_list().IDENT();
        var type = context.type().GetText();
        bool isArray = context.type().array_type() != null;

        foreach (var varName in varNames)
        {
            string name = varName.GetText();
            DeclareSymbol(name, new SymbolInfo
            {
                Type = type,
                Kind = SymbolKind.Variable,
                IsArray = isArray
            });
        }
        return null;
    }

    public override object VisitProcedure_decl(AlgolSubsetParser.Procedure_declContext context)
    {
        string name = context.IDENT().GetText();
        
        DeclareSymbol(name, new SymbolInfo
        {
            Type = "void",
            Kind = SymbolKind.Procedure
        });

        // Vstup do nov�ho rozsahu pro proceduru
        EnterScope();

        // Zpracov�n� parametr�
        if (context.param_list() != null)
        {
            Visit(context.param_list());
        }

        // Zpracov�n� t�la procedury (m��e obsahovat vno�en� deklarace)
        Visit(context.block());

        ExitScope();
        return null;
    }

    public override object VisitFunction_decl(AlgolSubsetParser.Function_declContext context)
    {
        string name = context.IDENT().GetText();
        string returnType = context.type().GetText();
        
        DeclareSymbol(name, new SymbolInfo
        {
            Type = returnType,
            Kind = SymbolKind.Function,
            ReturnType = returnType
        });

        Console.WriteLine($"Info: Deklarov�na funkce '{name}' s n�vratov�m typem '{returnType}'");

        // Vstup do nov�ho rozsahu pro funkci
        EnterScope();

        // Zpracov�n� parametr�
        if (context.param_list() != null)
        {
            Visit(context.param_list());
        }

        // Zpracov�n� t�la funkce (m��e obsahovat vno�en� deklarace)
        Visit(context.block());

        ExitScope();
        return null;
    }

    public override object VisitParam(AlgolSubsetParser.ParamContext context)
    {
        string name = context.IDENT().GetText();
        string type = context.type().GetText();
        bool isArray = context.type().array_type() != null;
        bool isFunctionType = context.type().function_type() != null; // NOV�: Kontrola funk�n�ho typu

        // NOV�: Rozli�en� funk�n�ho parametru
        var kind = isFunctionType ? SymbolKind.Function : SymbolKind.Variable;

        DeclareSymbol(name, new SymbolInfo
        {
            Type = type,
            Kind = kind,
            IsArray = isArray,
            IsFunctionType = isFunctionType
        });

        if (isFunctionType)
        {
            Console.WriteLine($"Info: Parametr '{name}' je funk�n�ho typu: {type}");
        }

        return null;
    }

    public override object VisitBlock(AlgolSubsetParser.BlockContext context)
    {
        // Zpracov�n� v�ech deklarac� a p��kaz� v bloku
        return VisitChildren(context);
    }

    public override object VisitAssignment(AlgolSubsetParser.AssignmentContext context)
    {
        string name = context.IDENT().GetText();
        var symbol = LookupSymbol(name);
        
        if (symbol == null)
        {
            Console.WriteLine($"Chyba: Prom�nn� '{name}' nen� deklarov�na.");
        }
        else if (symbol.Kind != SymbolKind.Variable)
        {
            Console.WriteLine($"Chyba: '{name}' nen� prom�nn� (je to {symbol.Kind}).");
        }

        // Zkontrolovat pravou stranu p�i�azen�
        if (context.expression() != null && context.expression().Length > 0)
        {
            Visit(context.expression(0));
        }
        
        return null;
    }

    public override object VisitProcedure_call(AlgolSubsetParser.Procedure_callContext context)
    {
        string name = context.IDENT().GetText();
        var symbol = LookupSymbol(name);
        
        if (symbol == null)
        {
            Console.WriteLine($"Chyba: Procedura/funkce '{name}' nen� deklarov�na.");
        }
        else if (symbol.Kind != SymbolKind.Procedure && symbol.Kind != SymbolKind.Function)
        {
            Console.WriteLine($"Chyba: '{name}' nen� procedura ani funkce.");
        }
        else
        {
            int currentScopeLevel = 0;
            foreach (var scope in scopes)
            {
                if (scope.ContainsKey(name))
                {
                    string scopeType = currentScopeLevel == scopes.Count - 1 ? "glob�ln�" : "lok�ln�";
                    Console.WriteLine($"Info: Vol�na {scopeType} {symbol.Kind.ToString().ToLower()} '{name}'");
                    break;
                }
                currentScopeLevel++;
            }
        }

        // Zkontrolovat argumenty
        if (context.expression() != null)
        {
            foreach (var expr in context.expression())
            {
                Visit(expr);
            }
        }
        return null;
    }

    public override object VisitFactor(AlgolSubsetParser.FactorContext context)
    {
        if (context.IDENT() != null && context.expression().Length == 0 && context.procedure_call() == null)
        {
            // Samotn� identifik�tor (prom�nn� nebo pole jako celek)
            string name = context.IDENT().GetText();
            var symbol = LookupSymbol(name);
            
            if (symbol == null)
            {
                Console.WriteLine($"Chyba: Identifik�tor '{name}' nen� deklarov�n.");
            }
        }
        return VisitChildren(context);
    }
}
